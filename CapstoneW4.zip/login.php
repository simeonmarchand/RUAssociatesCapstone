<?php // login.php
	$hn = 'localhost'; //hostname
	$db = 'capstone'; //database
	$un = 'root'; //username
	$pw = ''; //password
?>