<?php
  // Retrieve the database login info
  require_once 'login.php';

  // Create a connection to the database
  $connection = new mysqli($hn, $un, $pw, $db);

  // Check for a connection error
  if ($connection->connect_error) die($connection->connect_error);

  if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
  }
  else {
    echo "Error: You can only access this page using a POST request.";
    exit();
  }
  ?>